<div class="mega-nav-widget">
    <?php echo apply_filters('themefuse_shortcodes', $settings['tf_megamenu_html']); ?>
</div>
