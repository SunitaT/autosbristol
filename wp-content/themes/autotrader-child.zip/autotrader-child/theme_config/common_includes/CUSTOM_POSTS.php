<?php
/**
 * Create custom posts types
 *
 * @since AutoTrader 1.0
 */

