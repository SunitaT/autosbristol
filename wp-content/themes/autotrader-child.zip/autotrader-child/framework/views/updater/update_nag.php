<div id="update-nag">
    <?php echo sprintf(__('A ThemeFuse update is available. Go to %s Updates %s page for more info.', 'tfuse'), '<a href="admin.php?page=tfupdates">', '</a>') ?>
</div>