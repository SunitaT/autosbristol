<?php
/*-----------------------------------------------------------------------------------

TABLE OF CONTENTS

- Hook Definitions

-----------------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------------*/
/* Hook Definitions */
/*-----------------------------------------------------------------------------------*/
// General
function tfuse_title() { do_action ( 'tfuse_title' ); }
function tfuse_meta()  { do_action ( 'tfuse_meta' ); }
function tfuse_head()  { do_action ( 'tfuse_head' ); }
function tfuse_footer() { do_action( 'tfuse_footer' ); }

function tfuse_comments() { do_action ( 'tfuse_comments'); }
